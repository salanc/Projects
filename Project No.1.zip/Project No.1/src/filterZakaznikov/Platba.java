package filterZakaznikov;

public enum Platba {
    KREDIT, PAUSAL
}
