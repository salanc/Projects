package filterZakaznikov;
/**
 * Trieda Zakaznik reprezentuje popis uzivatela sluzieb lubovolneho mobilneho operatora.
 */
public class Zakaznik {

    private final String meno;
    private final String telefonneCislo;
    boolean hlas;
    boolean internet;
    Platba typPlatby;
    private final double stavUctu;

    /**
     * Tvorba konstruktora triedy Zakaznik s nasledujucimi parametrami:
     * @param meno           reprezentuje retazec tvoreny rodnym menom a priezviskom zakaznika
     * @param telefonneCislo reprezentuje mobilne telefonne cislo zakaznika vo formate +421..., alebo vo formate
     *                       bez predvolby
     * @param hlas           reprezentuje funkciu volnych minut zakaznika (zakaznik moze a nemusi vyuzivat danu sluzbu)
     * @param internet       reprezentuje volitelnu funkciu (zakaznik moze a nemusi vyuzit tuto sluzbu, pricom plati
     *                       podmienka, ze zakaznik musi vyuzitaspon jednu sluzbu: hlas / internet)
     * @param stavUctu       reprezentuje podlznosti voci operatorovi
     */
    public Zakaznik(String meno, String telefonneCislo, boolean hlas, boolean internet, Platba typPlatby, double stavUctu) {
        this.meno = meno;
        this.telefonneCislo = telefonneCislo;
        this.hlas = hlas;
        this.internet = internet;
        this.typPlatby = typPlatby;
        this.stavUctu = stavUctu;
    }

    /**
     * Getter metoda
     * @return telefonne cislo zakaznika
     */
    public String getTelefonneCislo() {
        return telefonneCislo;
    }

    /**
     * Getter metoda
     * @return informaciu o odoberani sluzby hlas
     */
    public boolean isHlas() {
        return hlas;
    }

    /**
     * Getter metoda
     * @return informaciu o odoberani sluzby internet
     */
    public boolean isInternet() {
        return internet;
    }

    /**
     * Getter metoda
     * @return hodnotu podlznosti voci operatorovi
     */
    public double getStavUctu() {
        return stavUctu;
    }

    /**
     * Getter metoda toString
     * @return informacie v naformatovanom tvare
     */
    @Override
    public String toString() {
        return "Zakaznik: " +
                "Meno = " + meno +
                ", TelefonneCislo = " + telefonneCislo +
                ", Hlas = " + hlas +
                ", Internet = " + internet +
                ", TypPlatby = " + typPlatby +
                ", StavUctu = " + stavUctu;
    }
}
