package filterZakaznikov;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

/**
 * Trieda FilterZakaznikov triedi a zobrazuje objekty typu Zakaznik zo "suboru zakaznici.csv" podla kriterii:
 * Zakaznik pre fakturaciu (zaporny stav uctu)
 * Zakaznik so sluzbou Hlas
 * Zakaznik so sluzbou Internet
 * Zakaznik s mobilnym kontaktom (zacinajucim na 09....)
 * Filter je mozne spustit pomocou terminalu za pomoci argumentov [0] -> "f","h","i","m"
 */

public class FilterZakaznikov {

    public static void main(String[] args) throws FileNotFoundException {

        FileReader citacSuboru = new FileReader("zakaznici.csv");
        Scanner skener = new Scanner(citacSuboru);

        DatabazaZakaznikov databazaZakaznikov = new DatabazaZakaznikov();

        while (skener.hasNextLine()) {
            String novyRiadok = skener.nextLine();
            String[] dataOZakaznikovi = novyRiadok.split(",");

            Zakaznik zakaznik = new Zakaznik(
                    dataOZakaznikovi[0],
                    dataOZakaznikovi[1],
                    dataOZakaznikovi[2].equals("hlas"),
                    dataOZakaznikovi[3].equals("internet"),
                    dataOZakaznikovi[4].equals("kredit") ? Platba.KREDIT : Platba.PAUSAL,
                    Double.parseDouble(dataOZakaznikovi[5]));
            databazaZakaznikov.pridajZakaznika(zakaznik);
        }

        try {
            citacSuboru.close();
        } catch (IOException e) {
            System.out.println("Subor sa nepodarilo zavriet");
        }
        skener.close();

        switch (args[0]) {
            case "f" -> {
                System.out.println("\nZOZNAM ZAKAZNIKOV PRE FAKTURACIU:\n");
                databazaZakaznikov.vypisZakaznikovPreFakturaciu();
            }
            case "h" -> {
                System.out.println("\nZOZNAM ZAKAZNIKOV SO SLUZBOU HLAS:\n");
                databazaZakaznikov.vypisZakaznikovSoSluzbouHlas();
            }

            case "i" -> {
                System.out.println("\nZOZNAM ZAKAZNIKOV SO SLUZBOU INTERNET:\n");
                databazaZakaznikov.vypisZakaznikovSoSluzbouInternet();
            }
            case "m" -> {
                System.out.println("\nZOZNAM ZAKAZNIKOV S MOBILNYM KONTAKTOM:\n");
                databazaZakaznikov.vypisZakaznikovSMobilnymKontaktom(); }
            default -> System.out.println("\nMozny vyber z argumentov: 'f', 'h', 'i', 'm'");
        }
    }
}

