package filterZakaznikov;

import java.util.ArrayList;

public class DatabazaZakaznikov {

    /**
     * vytvorenie zoznamu s nazvom databazaZakaznikov s objektami typu Zakaznik.
     */
    public ArrayList<Zakaznik> databazaZakaznikov;

    /**
     * vytvorenie konstruktora - DatabazaZakaznikov
     * inicializacia zoznamu - databazaZakaznikov
     */
    public DatabazaZakaznikov() {
        databazaZakaznikov = new ArrayList<>();
    }

    /**
     * Metoda pridajZakaznika() pridava objekt typu Zakaznik do databazy: databazaZakaznikov.
     * @param zakaznik predstavuje konkretneho zakaznika pridaneho do databazaZakaznikov
     */
    public void pridajZakaznika(Zakaznik zakaznik) {
        databazaZakaznikov.add(zakaznik);
    }

    /**
     * Metoda vypisZakaznikovSMobilnymKontaktom() vyfiltruje zakaznikov mobilnym cislom bez predvolby (v tvare: 09...).
     */
    public void vypisZakaznikovSMobilnymKontaktom() {
        for (Zakaznik zakaznik : databazaZakaznikov) {
            if (zakaznik.getTelefonneCislo().startsWith("09")) {
                System.out.println(zakaznik);
            }
        }
    }

    /**
     * Metoda vypisZakaznikovSoSluzbouHlas() vyfiltruje zakaznikov s predplatenou sluzbou hlas.
     */
    public void vypisZakaznikovSoSluzbouHlas() {
        for (Zakaznik zakaznik : databazaZakaznikov) {
            if (zakaznik.isHlas()) {
                System.out.println(zakaznik);
            }
        }
    }

    /**
     * Metoda vypisZakaznikovSoSluzbouInternet() vyfiltruje zakaznikov s predplatenou sluzbou internet.
     */
    public void vypisZakaznikovSoSluzbouInternet() {
        for (Zakaznik zakaznik : databazaZakaznikov) {
            if (zakaznik.isInternet()) {
                System.out.println(zakaznik);
            }
        }
    }

    /**
     * Metoda vypisZakaznikovPreFakturaciu() vyfiltruje zakaznikov so zapornym stavom uctu.
     */
    public void vypisZakaznikovPreFakturaciu() {
        for (Zakaznik zakaznik : databazaZakaznikov) {
            if (zakaznik.getStavUctu() < 0) {
                System.out.println(zakaznik);
            }
        }
    }
}
