package filterZakaznikov;

public class ZakazniciTester {

    public static void main(String[] args) {

        Zakaznik zakaznik1 = new Zakaznik("Karol Novak", "0905532820", true, false, Platba.KREDIT, -50);
        Zakaznik zakaznik2 = new Zakaznik("Jozko Mrkvicka", "05905532820", true, true, Platba.PAUSAL, 90);
        Zakaznik zakaznik3 = new Zakaznik("Peter Pavol", "0905532820", false, false, Platba.PAUSAL, -14);
        Zakaznik zakaznik4 = new Zakaznik("Marek Delej", "0905532820", false, true, Platba.KREDIT, 100);

        Zakaznik[] zakaznici = {zakaznik1, zakaznik2, zakaznik3, zakaznik4};

        if (args[0].equals("f")) {
            vypisZakaznikovPreFakturaciu(zakaznici);
        } else if (args[0].equals("m")) {
            vypisZakaznikovSMobilnymKontaktom(zakaznici);
        } else if (args[0].equals("h")) {
            vypisZakaznikovSoSluzbouHlas(zakaznici);
        } else if (args[0].equals("i")) {
            vypisZakaznikovSoSluzbouInternet(zakaznici);
        }
    }
    private static void vypisZakaznikovSoSluzbouInternet(Zakaznik[] zakaznici) {
        for (Zakaznik zakaznik : zakaznici) {
            if (zakaznik.isInternet()) {
                System.out.println(zakaznik);
            }
        }
    }
    private static void vypisZakaznikovSoSluzbouHlas(Zakaznik[] zakaznici) {
        for (Zakaznik zakaznik : zakaznici) {
            if (zakaznik.isHlas()) {
                System.out.println(zakaznik);
            }
        }
    }
    private static void vypisZakaznikovSMobilnymKontaktom(Zakaznik[] zakaznici) {
        for (Zakaznik zakaznik : zakaznici) {
            if (zakaznik.getTelefonneCislo().startsWith("09")) {
                System.out.println(zakaznik);
            }
        }
    }
    private static void vypisZakaznikovPreFakturaciu(Zakaznik[] zakaznici) {
        for (Zakaznik zakaznik : zakaznici) {
            if (zakaznik.getStavUctu() < 0) {
                System.out.println(zakaznik);
            }
        }
    }
}

