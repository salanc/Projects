package prioritizacia_pracovnych_uloh;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Trieda Aplikacia
 * Dana trieda riesi prioritizaciu a spracovanie nahromadenych pracovnych uloh na zaklade ich typu (administrativa
 * a reklamacia).
 * Pracovne ulohy su nacitane zo suboru "pracovne-ulohy.csv" a nasledne spracovavane.
 * Aplikacia na zaklade dolezitosti a datumu vytvorenia ulohy vygeneruje najprioritnejsiu pracovnu ulohu (rozdelenie na
 * prioritne a druhorade pracovne ulohy; obe zoradene podla datumu zadania ulohy).
 * Aplikacia generuje najprioritnejsiu pracovnu ulohu a dava moznosti jej riesenia na zaklade typu pracovnej ulohy:
 * Reklamacia: vyriesPracovnuUlohu / zrusPracovnuUlohu.
 * Administrativa:  vyriesPracovnuUlohu / prelozUlohuODen.
 * Aplikacia umoznuje pridanie dodatocnych pracovnych uloh z textoveho suboru "ulohy-na-pridanie.csv".
 * Po vyrieseni sa pracovna uloha zapise do suboru "spracovane-ulohy.csv".
 * @author  Samuel Lancos
 * @since   2023-10-31
 */

public class Aplikacia {

    public static void main(String[] args) {

        ArrayList<PracovnaUloha> pracovneUlohy = new ArrayList<>();
        ArrayList<PracovnaUloha> prioritne = new ArrayList<>();
        ArrayList<PracovnaUloha> druhorade = new ArrayList<>();

        Utilities.nacitajDataZoSuboruPracovneUlohy(pracovneUlohy);
        Utilities.rozdelUlohyNaZakladePriority(pracovneUlohy, prioritne, druhorade);
        Utilities.prepisSuborPracovneUlohy(pracovneUlohy, "pracovne-ulohy.csv");

        String ZLTA = "\u001B[33m";
        String RESET = "\u001B[0m";
        String MODRA = "\u001B[36m";

        System.out.println(ZLTA + "\nZOZNAM ZOTRIEDENYCH ULOH NA ZAKLADE FIREMNEJ PRIORITIZACIE:\n" + RESET);
        zobrazZoznam(pracovneUlohy);

        ArrayList<PracovnaUloha> zoznamUlohNaPridanie = new ArrayList<>();




        Scanner vstup = new Scanner(System.in);
        String menuVolba;

        System.out.println(ZLTA + "\nCO SI PRAJETE VYKONAT? :-)" + RESET);
        System.out.println(MODRA + "MOZNOSTI: 1 - Prevezmi najakutnejsiu ulohu, 2 - Aktualizuj zoznam pracovnych uloh, 3 - Ukonci program!" + RESET);

        do {
            menuVolba = (vstup.nextLine());
            switch (menuVolba) {
                case "1" -> {
                    if (pracovneUlohy.isEmpty()) {
                        System.out.println(MODRA + "Zoznam pracovnych uloh je prazdny. :-)" + RESET);
                        System.out.println(ZLTA + "Ukoncujem program" + RESET);
                        System.exit(0);
                        break;
                    }
                    PracovnaUloha.prevezmiPracovuUlohu(pracovneUlohy);
                    if (pracovneUlohy.get(0).getTypUlohy().equals("administrativa")) {
                        System.out.println(MODRA + "MOZNOSTI: 1 - Vyries ulohu, 2 - Preloz pracovnu ulohu o 1 den, 3 - Ukonci program!" + RESET);
                        menuVolba = (vstup.nextLine());
                        switch (menuVolba) {
                            case "1" -> {
                                PracovnaUloha.vyriesPracovuUlohu(pracovneUlohy);
                                System.out.println(ZLTA + "Uloha vyriesena a presunuta do zoznamu splnenych pracovnych uloh. :-)" + ZLTA);
                                System.out.println(MODRA + "MOZNOSTI: 1 - Prevezmi najakutnejsiu ulohu, 2 - Aktualizuj zoznam pracovnych uloh, 3 - Ukonci program!" + RESET);
                            }
                            case "2" -> {
                                Administrativa.prelozPracovuUlohuODen(pracovneUlohy, prioritne, druhorade);
                                System.out.println(ZLTA + "Uloha odlozena o 1 den. :-)" + RESET);
                                System.out.println(MODRA + "MOZNOSTI: 1 - Prevezmi najakutnejsiu ulohu, 2 - Aktualizuj zoznam pracovnych uloh, 3 - Ukonci program!" + RESET);
                            }
                            case "3" -> {
                                System.out.println(ZLTA + "Aplikacia uspesne zatvorena. :-)" + RESET);
                                System.exit(0);
                            }
                            default -> System.out.println(ZLTA + "Prosim skuste znova. :-)" + RESET);
                        }
                    } else if (pracovneUlohy.get(0).getTypUlohy().equals("reklamacia")) {
                        System.out.println(MODRA + "MOZNOSTI: 1 - Vyries pracovnu ulohu, 2 - Zrus pracovnu ulohu, 3 - Ukonci program!" + RESET);
                        menuVolba = (vstup.nextLine());
                        switch (menuVolba) {
                            case "1" -> {
                                PracovnaUloha.vyriesPracovuUlohu(pracovneUlohy);
                                System.out.println(ZLTA + "Uloha vyriesena a presunuta do zoznamu splnenych pracovnych uloh. :-)" + ZLTA);
                                System.out.println(MODRA + "MOZNOSTI: 1 - Prevezmi najakutnejsiu ulohu, 2 - Aktualizuj zoznam pracovnych uloh, 3 - Ukonci program!" + RESET);
                            }
                            case "2" -> {
                                Reklamacia.zrusPracovuUlohu(pracovneUlohy);
                                System.out.println(MODRA + "MOZNOSTI: 1 - Prevezmi najakutnejsiu ulohu, 2 - Aktualizuj zoznam pracovnych uloh, 3 - Ukonci program!" + RESET);
                            }
                            case "3" -> {
                                System.out.println(ZLTA + "Aplikacia uspesne zatvorena. :-)" + RESET);
                                System.exit(0);
                            }
                            default -> {
                                System.out.println(ZLTA + "Prosim skuste znova. :-)" + RESET);
                                System.out.println(MODRA + "MOZNOSTI: 1 - Prevezmi najakutnejsiu ulohu, 2 - Aktualizuj zoznam pracovnych uloh, 3 - Ukonci program!" + RESET);
                            }
                        }
                    }
                }
                case "2" -> {
                    Utilities.aktualizujZoznam("pracovne-ulohy.csv", "ulohy-na-pridanie.csv",
                            pracovneUlohy, zoznamUlohNaPridanie, prioritne, druhorade);
                    System.out.println(ZLTA + "\nZOZNAM PRACOVNYCH ULOH USPESNE AKTUALIZOVANY. :-)" + RESET);
                    System.out.println(ZLTA + "ZOZNAM ZOTRIEDENYCH ULOH NA ZAKLADE FIREMNEJ PRIORITIZACIE:\n" + RESET);
                    zobrazZoznam(pracovneUlohy);
                    System.out.println(MODRA + "\nMoznosti: 1 - Prevezmi najakutnejsiu ulohu, 2 - Aktualizuj zoznam pracovnych uloh, 3 - Ukonci program!" + RESET);
                }
                case "3" -> {
                    System.out.println(ZLTA + "Aplikacia uspesne zatvorena. :-)" + RESET);
                    System.exit(0);
                }
                default -> {
                    System.out.println(ZLTA + "Nespravny vyber, prosim skuste znovu. :-)" + RESET);
                    System.out.println(MODRA + "Moznosti: 1 - Prevezmi najakutnejsiu ulohu, 2 - Aktualizuj zoznam pracovnych uloh, 3 - Ukonci program!" + RESET);
                }
            }
        }
        while (true);
    }
    public static void zobrazZoznam(ArrayList<PracovnaUloha> zoznam) {
        for (PracovnaUloha pracovnaUloha : zoznam) {
            System.out.println(pracovnaUloha);
        }
    }
}