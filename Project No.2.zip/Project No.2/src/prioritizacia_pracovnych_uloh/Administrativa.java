package prioritizacia_pracovnych_uloh;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Locale;

/**
 * Trieda Administrativa
 * <p>Trieda reprezentuje administrativny typ prac. ulohy, ktory je podtriedou triedy PracovnaUloha.
 */
public class Administrativa extends PracovnaUloha {

    /**
     * Vznik objektu Administrativa, ktory dedi parametre z nadtriedy PracovnaUloha.
     * @param typUlohy retazec obsahujuci informacie o type ulohy: administrativa
     * @param popisUlohy retazec vyjadrujuci konkretny popis pracovnej ulohy typu Administrativa
     * @param datumVznikuUlohy retazec popisujuci datum zadania konkretnej administrativnej pracovnej ulohy
     * @param prioritne boolean popisujuci dolezitost vybavenia administrativnej pracovnej ulohy
     */
    public Administrativa(String typUlohy, String popisUlohy, String datumVznikuUlohy, boolean prioritne) {
        super(typUlohy, popisUlohy, datumVznikuUlohy, prioritne);
    }

    /**
     * Metoda preklada vyriesenie pracovnej ulohy typu Administrativa o 1 den.
     * @param zoznam repreprezentuje Arraylist s pracovnymi ulohami
     * @param dolezite repreprezentuje Arraylist s prioritnymi pracovnymi ulohami
     * @param nedolezite repreprezentuje Arraylist s druhoradymi pracovnymi ulohami
     */
    public static void prelozPracovuUlohuODen(ArrayList<PracovnaUloha> zoznam, ArrayList<PracovnaUloha> dolezite,
                                              ArrayList<PracovnaUloha> nedolezite) {

        String datumVznikuUlohy = zoznam.get(0).getDatumVznikuUlohy();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ENGLISH);
        LocalDate lokalnyDatum = LocalDate.parse(datumVznikuUlohy, formatter);
        LocalDate novyDatum = lokalnyDatum.plusDays(1);
        String novyDatumString = novyDatum.format(formatter);
        zoznam.get(0).setDatumVznikuUlohy(novyDatumString);

        Utilities.rozdelUlohyNaZakladePriority(zoznam, dolezite, nedolezite);
        Utilities.prepisSuborPracovneUlohy(zoznam, "pracovne-ulohy.csv");
    }
}
