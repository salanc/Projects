package prioritizacia_pracovnych_uloh;

import java.util.ArrayList;

/**
 * Trieda PracovnaUloha
 * <p>Reprezentuje detaily o pracovnej ulohe (poziadavke od zakaznika) vzniknutej voci spolocnosti FIKTIV s.r.o.,
 * prevadzkujucej autoservis.
 */
public class PracovnaUloha {

    private final String typUlohy;
    private final String popisUlohy;
    private String datumVznikuUlohy;
    private final boolean dolezite;

    /**
     * Vytvara pracovnu ulohu s konkretnymi parametrami.
     * @param typUlohy retazec obsahujuci informacie o type ulohy (administrativa / reklamacia)
     * @param popisUlohy retazec popisujuci konkretnu pracovnu ulohu
     * @param datumVznikuUlohy retazec popisujuci datum zadania konkretnej pracovnej ulohy
     * @param prioritne boolean popisujuci dolezitost vybavenia pracovnej ulohy
     */
    public PracovnaUloha(String typUlohy, String popisUlohy, String datumVznikuUlohy, boolean prioritne) {
        this.typUlohy = typUlohy;
        this.popisUlohy = popisUlohy;
        this.datumVznikuUlohy = datumVznikuUlohy;
        this.dolezite = prioritne;
    }

    /**
     * Metoda zobrazuje pracovnu ulohu s indexom 0.
     * @param zoznam repreprezentuje Arraylist s pracovnymi ulohami
     */
    public static void prevezmiPracovuUlohu(ArrayList<PracovnaUloha> zoznam) {
        System.out.println(ZELENA + "Vygenerovana pracovna uloha na zaklade firemnej prioritizacie:" + RESET);
        System.out.println(zoznam.get(0).toString());
    }

    /**
     * Metoda reprezentuje "vyriesie" pracovnej ulohy, odstrani ju zo zoznamu uloh a prepise subor "pracovne-ulohy.csv".
     * @param zoznam repreprezentuje Arraylist s pracovnymi ulohami
     */
    public static void vyriesPracovuUlohu(ArrayList<PracovnaUloha> zoznam) {
        Utilities.prepisSuborSpracovaneUlohy(zoznam, "spracovane-ulohy.csv");
        zoznam.remove(0);
        Utilities.prepisSuborPracovneUlohy(zoznam, "pracovne-ulohy.csv");
    }

    /**
     * Getter metoda.
     * @return retazec obsahujuci informaciu o type pracovnej ulohy
     */
    public String getTypUlohy() {
        return typUlohy;
    }

    /**
     * Getter metoda.
     * @return retazec obsahujuci informaciu o popise pracovnej ulohy
     */
    public String getPopisUlohy() {
        return popisUlohy;
    }

    /**
     * Getter metoda.
     * @return retazec obsahujuci informaciu o datume vzniku pracovnej ulohy
     */
    public String getDatumVznikuUlohy() {
        return datumVznikuUlohy;
    }

    /**
     * Setter metoda.
     * <p>zmena informacie o datume vzniku pracovnej ulohy
     */
    public void setDatumVznikuUlohy(String datumVznikuUlohy) {
        this.datumVznikuUlohy = datumVznikuUlohy;
    }

    /**
     * Getter metoda.
     * @return retazec obsahujuci informaciu o dolezitosti pracovnej ulohy
     */
    public boolean isDolezite() {
        return dolezite;
    }

    static String RESET = "\u001B[0m";
    static String CERVENA = "\u001B[34m";
    static String ZELENA = "\u001B[32m";

    /**
     * Metoda toString() zobrazi vyformatovanu pracovnu ulohu do konzoly.
     * @return formatovany retazec obsahujuci vseobecne informacie o pracovnej ulohe
     */
    @Override
    public String toString() {
        return "Pracovna uloha: " +
                "typ = " + CERVENA + typUlohy + RESET +
                ", popis = " + CERVENA + popisUlohy + RESET +
                ", datum zadania = " + CERVENA + datumVznikuUlohy + RESET +
                ", dolezite = " + CERVENA + dolezite + RESET;
    }
}
