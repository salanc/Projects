package prioritizacia_pracovnych_uloh;

import java.util.ArrayList;

/**
 * Trieda Reklamacia
 * <p> Trieda reprezentuje pracovnu ulohu typu Reklamacia, ktory je podtriedou triedy PracovnaUloha.
 */
public class Reklamacia extends PracovnaUloha {

    /**
     * Vznik objektu typu Reklamacia, ktory dedi parametre z nadtriedy PracovnaUloha.
     * @param typUlohy retazec obsahujuci informacie o type ulohy: Reklamacia
     * @param popisUlohy retazec vyjadrujuci konkretny popis pracovnej ulohy typu Reklamacia
     * @param datumVznikuUlohy retazec popisujuci datum zadania konkretnej reklamacie
     * @param prioritne boolean popisujuci dolezitost vybavenia reklamacie
     */
    public Reklamacia(String typUlohy, String popisUlohy, String datumVznikuUlohy, boolean prioritne) {
        super(typUlohy, popisUlohy, datumVznikuUlohy, prioritne);
    }

    static String ZLTA = "\u001B[33m";

    /**
     * Metoda ignoruje pridelenu Reklamaciu a odstrani ju zo suboru "pracovne-ulohy.csv".
     * @param ulohy reprezentuje Arraylist s pracovnymi ulohami
     */
    public static void zrusPracovuUlohu(ArrayList<PracovnaUloha> ulohy) {
        ulohy.remove(0);
        Utilities.prepisSuborPracovneUlohy(ulohy, "pracovne-ulohy.csv");
        System.out.println(ZLTA + "Uloha bola odstranena. :-)" + RESET);
    }
}
