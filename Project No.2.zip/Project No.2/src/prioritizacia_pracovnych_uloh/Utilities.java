package prioritizacia_pracovnych_uloh;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * Trieda Utilities
 * <p>Obsahuje pomocne metody potrebne pre spravnu funkcionalitu Aplikacie.
 */
public class Utilities {

    public static final Comparator<PracovnaUloha> PODLA_DATUMU = Utilities::compare;

    /**
     * Metoda zotriedZoznam() zotriedi Arraylist na zaklade datumu zadania pracovnej ulohy.
     *
     * @param zoznam reprezentuje Arraylist so vsetkymi pracovnymi ulohami
     */
    public static void zotriedZoznam(ArrayList<PracovnaUloha> zoznam) {
        zoznam.sort(PODLA_DATUMU);
    }

    /**
     * Metoda nacitajDataZoSuboruPracovneUlohy() nacita data zo suboru "prcovne-ulohy.csv".
     *
     * @param zoznam reprezentuje Arraylist so vsetkymi pracovnymi ulohami
     */
    public static void nacitajDataZoSuboruPracovneUlohy(ArrayList<PracovnaUloha> zoznam) {
        FileReader citacSuboru;
        try {
            citacSuboru = new FileReader("pracovne-ulohy.csv");
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        Scanner skener = new Scanner(citacSuboru);

        while (skener.hasNextLine()) {
            String riadokZoSuboru = skener.nextLine();
            String[] dataPracovnaUloha = riadokZoSuboru.split(",");

            PracovnaUloha uloha = new PracovnaUloha(dataPracovnaUloha[0], dataPracovnaUloha[1], dataPracovnaUloha[2],
                    dataPracovnaUloha[3].contains("dolezite"));
            zoznam.add(uloha);
        }
        try {
            citacSuboru.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        skener.close();
    }

    /**
     * Metoda rozdelUlohyNaZakladePriority() rozdeluje hlavny zoznam na zaklade dolezitosti, zotriedi ich na zaklade
     * datumu vzniku pracovnej ulohy a nasedne spoji dva zoznamy do finalneho hlavneho Arraylistu.
     *
     * @param hlavnyZoznam reprezentuje Arraylist so vsetkymi pracovnymi ulohami
     * @param dolezite     reprezentuje Arraylist s dolezitymi pracovnymi ulohami
     * @param nedolezite   reprezentuje Arraylist s nedolezitymi pracovnymi ulohami
     */
    public static void rozdelUlohyNaZakladePriority(ArrayList<PracovnaUloha> hlavnyZoznam,
                                                    ArrayList<PracovnaUloha> dolezite,
                                                    ArrayList<PracovnaUloha> nedolezite) {
        dolezite.clear();
        nedolezite.clear();

        for (PracovnaUloha pracovnaUloha : hlavnyZoznam) {
            if (pracovnaUloha.isDolezite()) {
                dolezite.add(pracovnaUloha);
            } else {
                nedolezite.add(pracovnaUloha);
            }
        }
        hlavnyZoznam.clear();
        zotriedZoznam(dolezite);
        zotriedZoznam(nedolezite);
        spojZoznamy(hlavnyZoznam, dolezite, nedolezite);
    }

    public static void spojZoznamy(ArrayList<PracovnaUloha> hlavnyZoznam,
                                   ArrayList<PracovnaUloha> dolezite,
                                   ArrayList<PracovnaUloha> nedolezite) {
        hlavnyZoznam.addAll(dolezite);
        hlavnyZoznam.addAll(nedolezite);
    }

    /**
     * Metoda aktualizujZoznam() nacita subor "ulohy-na-pridanie" do Arraylistu pridavnyZoznam, pracovne ulohy prida do
     * zoznamu pracovny zoznam, zotriedi ich na zaklade prioritizacie a nasledne spoji vysledok do Arraylistu pracovne
     * ulohy.
     *
     * @param nazovSuboruPracovneUlohy   reprezentuje nazov suboru, kde su ulozene vsetky pracovne ulohy
     * @param nazovSuboruPreAktualizaciu reprezentuje nazov suboru, kde su ulozene pridavne pracovne ulohy
     * @param pracovneUlohy              reprezentuje Arraylist so vsetkymi pracovnymi ulohami
     * @param pridavnyZoznam             reprezentuje Arraylist s pridavnymi pracovnymi ulohami
     * @param dolezite                   reprezentuje Arraylist s dolezitymi pracovnymi ulohami
     * @param nedolezite                 reprezentuje Arraylist s nedolezitymi pracovnymi ulohami
     */
    public static void aktualizujZoznam(String nazovSuboruPracovneUlohy, String nazovSuboruPreAktualizaciu,
                                        ArrayList<PracovnaUloha> pracovneUlohy,
                                        ArrayList<PracovnaUloha> pridavnyZoznam,
                                        ArrayList<PracovnaUloha> dolezite,
                                        ArrayList<PracovnaUloha> nedolezite) {
        pracovneUlohy.clear();
        pridavnyZoznam.clear();

        FileReader citacSuboru;
        try {
            citacSuboru = new FileReader(nazovSuboruPracovneUlohy);

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        Scanner skener = new Scanner(citacSuboru);

        while (skener.hasNextLine()) {
            String riadokZoSuboru = skener.nextLine();
            String[] dataPracovnaUloha = riadokZoSuboru.split(",");

            PracovnaUloha uloha = new PracovnaUloha(dataPracovnaUloha[0], dataPracovnaUloha[1], dataPracovnaUloha[2],
                    dataPracovnaUloha[3].contains("dolezite"));
            pracovneUlohy.add(uloha);
        }
        skener.close();
        try {
            citacSuboru.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        FileReader citacSuboru2;
        try {
            citacSuboru2 = new FileReader(nazovSuboruPreAktualizaciu);

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        Scanner skener2 = new Scanner(citacSuboru2);
        while (skener2.hasNextLine()) {
            String riadokZoSuboru = skener2.nextLine();
            String[] dataPracovnaUloha = riadokZoSuboru.split(",");
            PracovnaUloha uloha = new PracovnaUloha(dataPracovnaUloha[0], dataPracovnaUloha[1], dataPracovnaUloha[2],
                    dataPracovnaUloha[3].contains("dolezite"));
            pridavnyZoznam.add(uloha);
        }
        skener2.close();
        try {
            citacSuboru2.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        pracovneUlohy.addAll(pridavnyZoznam);
        rozdelUlohyNaZakladePriority(pracovneUlohy, dolezite, nedolezite);
        zotriedZoznam(dolezite);
        zotriedZoznam(nedolezite);
        pracovneUlohy.clear();
        spojZoznamy(pracovneUlohy, dolezite, nedolezite);
        prepisSuborPracovneUlohy(pracovneUlohy, "pracovne-ulohy.csv");
        FileWriter fileWriter;
        try {
            fileWriter = new FileWriter(nazovSuboruPreAktualizaciu, false);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            fileWriter.write("Nic na pridanie");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Metoda prepisSuborPracovneUlohy() prepisuje subor "pracovne-ulohy.csv", kde uklada pracovne ulohy na zaklade
     * prioritizacie. Metoda obsahuje funkcionalitu, ktora kontroluje ulohy, ktore su starsie ako 15 dni pricom
     * automaticky zmeni ich stav na "dolezite".
     *
     * @param zoznam      reprezentuje Arraylist so vsetkymi pracovnymi ulohami
     * @param nazovSuboru reprezentuje nazov suboru, kde su ulozene vsetky pracovne ulohy
     */
    public static void prepisSuborPracovneUlohy(ArrayList<PracovnaUloha> zoznam, String nazovSuboru) {
        FileWriter zapisovac;
        try {
            zapisovac = new FileWriter(nazovSuboru);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
        LocalDate sucastnyDatum = LocalDate.now();
        Date aktualnyDatum;
        try {
            aktualnyDatum = sdf2.parse(sucastnyDatum.toString());
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        Date datumVytvoreniaUlohy;

        for (PracovnaUloha pracovnaUloha : zoznam) {
            try {
                datumVytvoreniaUlohy = sdf2.parse(pracovnaUloha.getDatumVznikuUlohy());
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }
            long datumVMiliSek = Math.abs(aktualnyDatum.getTime() - datumVytvoreniaUlohy.getTime());
            long rozdielDni = TimeUnit.DAYS.convert(datumVMiliSek, TimeUnit.MILLISECONDS);
            if (rozdielDni > 15 && pracovnaUloha.getTypUlohy().equals("reklamacia")) {
                try {
                    zapisovac.write(pracovnaUloha.getTypUlohy() + "," + pracovnaUloha.getPopisUlohy() + "," +
                            pracovnaUloha.getDatumVznikuUlohy() + ", " + "dolezite" + ", " + "\n");
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            } else {
                String vystup = pracovnaUloha.isDolezite() ? "dolezite" : "";
                try {
                    zapisovac.write(pracovnaUloha.getTypUlohy() + "," + pracovnaUloha.getPopisUlohy() + "," +
                            pracovnaUloha.getDatumVznikuUlohy() + ", " + vystup + ", " + "\n");
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        try {
            zapisovac.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Metoda prepisSuborSpracovaneUlohy() prepisuje subor s tym, ze zakazdym pripise do suboru "spracovane-ulohy.csv"
     * vyriesene subory.
     *
     * @param zoznamVyrieseneUlohy reprezentuje Arraylist so vsetkymi pracovnymi ulohami
     * @param nazovSuboru          reprezentuje nazov suboru, kde maju byt ulozene vyriesene pracovne ulohy
     */
    public static void prepisSuborSpracovaneUlohy(ArrayList<PracovnaUloha> zoznamVyrieseneUlohy, String nazovSuboru) {
        FileWriter outStream;
        try {
            outStream = new FileWriter(nazovSuboru, true);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {

            String popisDolezitosti = zoznamVyrieseneUlohy.get(0).isDolezite() ? "dolezite" : "nedolezite";
            outStream.write(zoznamVyrieseneUlohy.get(0).getTypUlohy() + ", " + zoznamVyrieseneUlohy.get(0).getPopisUlohy() +
                    ", " + zoznamVyrieseneUlohy.get(0).getDatumVznikuUlohy()
                    + ", " + popisDolezitosti + "\n");
        } catch (
                IOException e) {
            e.printStackTrace();
        }
        try {
            outStream.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private static int compare(PracovnaUloha o1, PracovnaUloha o2) {
        return o1.getDatumVznikuUlohy().compareTo(o2.getDatumVznikuUlohy());
    }
}
