CREATE DATABASE  IF NOT EXISTS `working_tasks`;
USE `working_tasks`;

DROP TABLE IF EXISTS `tasks`;

CREATE TABLE `tasks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `task_type`varchar(45) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `date` varchar(45) DEFAULT NULL,
  `significance` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

INSERT INTO `working_tasks`.`tasks` (`task_type`, `description`, `date`, `significance`) VALUES ('reklamacia', 'stazene otacanie volantom na mieste - EC: AA103AA', '2023-10-20', 'dolezite');
INSERT INTO `working_tasks`.`tasks` (`task_type`, `description`, `date`) VALUES ('reklamacia', 'odtrhnutie brzdoveho lanka - EC: AA980AB,2023-10-23', '2023-10-23');
INSERT INTO `working_tasks`.`tasks` (`task_type`, `description`, `date`, `significance`) VALUES ('reklamacia', 'otrebovane brzdopove oblozenie - EC: AA198AA', '2023-10-24', 'dolezite');
INSERT INTO `working_tasks`.`tasks` (`task_type`, `description`, `date`) VALUES ('reklamacia', 'chybne nastavenie svetlometu - EC: AA100AA', '2023-10-25');
INSERT INTO `working_tasks`.`tasks` (`task_type`, `description`, `date`, `significance`) VALUES ('administrativa', 'zabezpecit vyberove konanie pre poziciu: Automechanik', '2023-10-26', 'dolezite');
INSERT INTO `working_tasks`.`tasks` (`task_type`, `description`, `date`) VALUES ('administrativa', 'zaslat obratom datum autidu v spolocnosti FIKTIV s.r.o', '2023-10-26');
INSERT INTO `working_tasks`.`tasks` (`task_type`, `description`, `date`, `significance`) VALUES ('reklamacia', 'kontrolka so symbolom vykricnika na pristrojovom panely - EC', '2023-10-26', 'dolezite');
INSERT INTO `working_tasks`.`tasks` (`task_type`, `description`, `date`) VALUES ('reklamacia', 'porucha smerovych svetiel - EC: AA715AA', '2023-10-26');
INSERT INTO `working_tasks`.`tasks` (`task_type`, `description`, `date`, `significance`) VALUES ('administrativa', 'supis kancelarskych potrieb', '2023-10-26', 'dolezite');
INSERT INTO `working_tasks`.`tasks` (`task_type`, `description`, `date`) VALUES ('reklamacia', 'nerovnomerny tlak v pneumatikach - EC', '2023-10-27');
INSERT INTO `working_tasks`.`tasks` (`task_type`, `description`, `date`, `significance`) VALUES ('reklamacia', 'zla geometria prednej napravy - EC', '2023-10-28', 'dolezite');

SELECT * FROM working_tasks.tasks;