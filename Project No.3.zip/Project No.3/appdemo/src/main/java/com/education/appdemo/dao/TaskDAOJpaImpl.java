package com.education.appdemo.dao;

import com.education.appdemo.entity.Task;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class TaskDAOJpaImpl implements TaskDAO{

    private EntityManager entityManager;

    public TaskDAOJpaImpl(EntityManager theEntityManager) {
        entityManager = theEntityManager;
    }

    @Override
    public List<Task> findAll() {
        TypedQuery<Task> typedQuery = entityManager.createQuery("from Task", Task.class);
        List<Task> tasks = typedQuery.getResultList();
        return tasks;
    }
}
