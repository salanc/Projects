package com.education.appdemo.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "tasks")
public class Task {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "task_type")
    private String taskType;

    @Column(name = "description")
    private String description;

    @Column(name = "date")
    private String date;

    @Column(name = "significance")
    private String significance;

    public Task() {
    }

    public Task(String taskType, String description, String date, String significance) {
        this.taskType = taskType;
        this.description = description;
        this.date = date;
        this.significance = significance;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTaskType() {
        return taskType;
    }

    public void setTaskType(String taskType) {
        this.taskType = taskType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getSignificance() {
        return significance;
    }

    public void setSignificance(String significance) {
        this.significance = significance;
    }

    @Override
    public String toString() {
        return "Task{" +
                "id=" + id +
                ", taskType='" + taskType + '\'' +
                ", description='" + description + '\'' +
                ", date='" + date + '\'' +
                ", significance='" + significance + '\'' +
                '}';
    }
}
