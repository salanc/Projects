package com.education.appdemo.rest;


import com.education.appdemo.dao.TaskDAO;
import com.education.appdemo.entity.Task;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/education")
public class TaskRestController {

    private TaskDAO taskDAO;

    public TaskRestController(TaskDAO thisTaskDAO) {
        taskDAO = thisTaskDAO;
    }

    @GetMapping("/tasks")
    public List<Task> findAll() {
        return taskDAO.findAll();
    }
}
