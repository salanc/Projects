package com.education.appdemo.dao;

import com.education.appdemo.entity.Task;

import java.util.List;

public interface TaskDAO {

    List<Task> findAll();
}
