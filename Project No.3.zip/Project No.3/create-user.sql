-- Drop user first if they exist
DROP USER if exists 'user'@'%' ;

-- Now create user with prop privileges
CREATE USER 'user'@'%' IDENTIFIED BY 'password';

GRANT ALL PRIVILEGES ON * . * TO 'user'@'%';